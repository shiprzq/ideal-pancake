import {createContext,useContext,useEffect,useState,type ReactNode} from 'react';
import type {Session} from '@supabase/supabase-js';
import supabase from '../lib/supabase';
import {handleGoogleRedirect} from '../lib/googleAuth';
handleGoogleRedirect();
const AuthContext=createContext<{session:Session|null;loading:boolean}>({session:null,loading:true});
export function AuthProvider({children}:{children:ReactNode}){const [session,setSession]=useState<Session|null>(null),[loading,setLoading]=useState(true);useEffect(()=>{supabase.auth.getSession().then(({data})=>{setSession(data.session);setLoading(false);});const {data:{subscription}}=supabase.auth.onAuthStateChange((_e,s)=>{setSession(s);setLoading(false);});return()=>subscription.unsubscribe();},[]);return <AuthContext.Provider value={{session,loading}}>{children}</AuthContext.Provider>;}
export const useAuth=()=>useContext(AuthContext);
